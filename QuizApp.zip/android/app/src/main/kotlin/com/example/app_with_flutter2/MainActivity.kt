package com.example.app_with_flutter2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
